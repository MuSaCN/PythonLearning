# Author:Zhang Yuan
#导入包，本质是import该目录下__init__.py，不import其他py文件
import package_test
print(package_test.age)
print(package_test.sex)
print(package_test.Test.name)


